const DB_NAME = "simco_analyzer_sync";
const DB_VERSION = 1;
const BUNDLE_STORE = "bundles";
const META_STORE = "meta";
const LATEST_BUNDLE_KEY = "latest";
const JOB_KEY = "job";

const STATEMENT_ENDPOINTS = [
  { key: "incomeCsv", name: "Income statement", url: "https://www.simcompanies.com/csv/income-statement/" },
  { key: "balanceCsv", name: "Balance sheet", url: "https://www.simcompanies.com/csv/balance-sheet/" },
  { key: "cashflowCsv", name: "Cash flow", url: "https://www.simcompanies.com/csv/cashflow-statement/" }
];
const SIMCOMPANIES_CONTEXT_URL = "https://www.simcompanies.com/headquarters/executives/";
const SIMCOMPANIES_LANDSCAPE_URL = "https://www.simcompanies.com/landscape/";

let activeJob = null;
let lastSimcotoolsRequestAt = 0;
let activeTradingSnapshot = null;
let cachedTradingSnapshot = null;

if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

chrome.action?.onClicked?.addListener(async (tab) => {
  if (!chrome.sidePanel?.open) return;
  try {
    if (tab?.id) {
      await chrome.sidePanel.open({ tabId: tab.id });
    } else {
      const window = await chrome.windows.getCurrent();
      await chrome.sidePanel.open({ windowId: window.id });
    }
  } catch {
    // setPanelBehavior covers supported browsers; this is only a best-effort fallback.
  }
});

function friendlyFetchError(url, response, bodyText) {
  const contentType = response.headers.get("content-type") || "";
  const looksLikeHtml = contentType.includes("text/html") || isBrowserCheckResponse(bodyText);

  if (looksLikeHtml && url.includes("simcompanies.com")) {
    return new Error("SimCompanies returned a login page instead of data. Open SimCompanies in this browser, log in, then run Sync Company Data again.");
  }

  if (looksLikeHtml) {
    return new Error(`Expected data but received a web page from ${new URL(url).hostname}.`);
  }

  return new Error(`Expected JSON but received an unreadable response from ${new URL(url).hostname}.`);
}

function isBrowserCheckResponse(text) {
  const body = String(text || "").trim().toLowerCase();
  return (
    /^\s*<!doctype html/i.test(text || "") ||
    /^\s*<html/i.test(text || "") ||
    body.includes("just a moment") ||
    body.includes("correct system time") ||
    body.includes("make sure your device has the correct system time")
  );
}

function browserCheckError() {
  return new Error("SimCompanies returned its browser-check page instead of JSON. Open or refresh SimCompanies until the game loads normally, then try again.");
}

function simcompaniesStatusError(response) {
  if (response.status === 400) {
    return new Error("SimCompanies rejected the request. Make sure the realm open on SimCompanies matches the realm selected in the extension.");
  }

  if (response.status === 401 || response.status === 403) {
    return new Error("SimCompanies did not allow this request. Open SimCompanies in this browser, log in, then run Sync Company Data again.");
  }

  return new Error(`Fetch failed (${response.status})`);
}

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(BUNDLE_STORE)) db.createObjectStore(BUNDLE_STORE);
      if (!db.objectStoreNames.contains(META_STORE)) db.createObjectStore(META_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function putStore(storeName, key, value) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).put(value, key);
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

async function getStore(storeName, key) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const request = tx.objectStore(storeName).get(key);
    request.onsuccess = () => resolve(request.result);
    tx.oncomplete = () => db.close();
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
  });
}

async function updateJob(patch) {
  activeJob = {
    ...(activeJob || {}),
    ...patch,
    updatedAt: Date.now()
  };
  await putStore(META_STORE, JOB_KEY, activeJob);
  chrome.runtime.sendMessage({ type: "syncProgress", job: activeJob }).catch(() => {});
  return activeJob;
}

async function fetchCsv(url) {
  const response = await fetch(url, {
    method: "GET",
    credentials: "include",
    headers: {
      accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "upgrade-insecure-requests": "1"
    }
  });
  if (!response.ok) throw simcompaniesStatusError(response);
  return response.text();
}

async function fetchJson(url, credentials = "include") {
  const response = await fetch(url, {
    method: "GET",
    credentials,
    headers: {
      accept: "application/json, text/plain, */*"
    }
  });
  if (!response.ok) throw simcompaniesStatusError(response);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    throw friendlyFetchError(url, response, text);
  }
}

async function fetchOptionalJson(url, fallbackValue) {
  try {
    return await fetchJson(url);
  } catch (error) {
    console.warn(`Optional JSON fetch failed: ${url}`, error);
    return fallbackValue;
  }
}

function queryTabs(query) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(query, (tabs) => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve(tabs || []);
    });
  });
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const error = chrome.runtime.lastError;
      if (error) reject(new Error(error.message));
      else resolve(response);
    });
  });
}

function removeTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.remove(tabId, () => resolve());
  });
}

function contextPageForApiUrl(url) {
  if (url.includes("/api/v2/companies/me/buildings/")) return SIMCOMPANIES_LANDSCAPE_URL;
  if (url.includes("/api/v2/players/me/companies/")) return SIMCOMPANIES_CONTEXT_URL;
  if (url.includes("/api/v2/companies/") && url.includes("/royalties/")) return SIMCOMPANIES_CONTEXT_URL;
  if (url.includes("/api/v3/contracts-incoming/") || url.includes("/api/v3/contracts-outgoing/")) {
    return "https://www.simcompanies.com/headquarters/warehouse/incoming-contracts/";
  }
  return SIMCOMPANIES_CONTEXT_URL;
}

async function openSimCompaniesTab(contextUrl = SIMCOMPANIES_CONTEXT_URL) {
  return chrome.tabs.create({ url: contextUrl, active: true });
}

async function fetchSimCompaniesJsonFromGamePage(url) {
  const contextUrl = contextPageForApiUrl(url);
  await updateJob({
    stage: "SimCompanies API",
    message: "Capturing SimCompanies API from official page",
    currentItem: url
  }).catch(() => {});

  const tab = await openSimCompaniesTab(contextUrl);
  if (!tab.id) throw new Error("Could not open SimCompanies API tab.");

  try {
    await updateJob({
      stage: "SimCompanies API",
      message: "Loading official page for API capture",
      currentItem: contextUrl
    }).catch(() => {});
    await waitForTabComplete(tab.id, 30000).catch(() => {});
    await sleep(2500);

    let lastError = "";
    for (let attempt = 1; attempt <= 4; attempt += 1) {
      try {
        const response = await sendTabMessage(tab.id, { type: "getCapturedJsonFromPage", url });
        if (response?.ok) return response.data;
        lastError = response?.error || "Could not capture SimCompanies API data from the official page.";
        if (/browser-check|correct system time/i.test(lastError)) throw browserCheckError();
      } catch (error) {
        lastError = error?.message || "SimCompanies API capture helper is not ready.";
        if (/browser-check|correct system time/i.test(lastError)) throw browserCheckError();
      }
      await sleep(1000);
    }
    throw new Error(lastError || "Timed out capturing SimCompanies API data from the official page.");
  } finally {
    await removeTab(tab.id).catch(() => {});
  }
}

async function fetchSimCompaniesJsonViaApiTab(url, { active = false, closeTab = true } = {}) {
  await updateJob({
    stage: "SimCompanies API",
    message: "Opening SimCompanies API page fallback",
    currentItem: url
  }).catch(() => {});

  const tab = await chrome.tabs.create({ url, active });
  if (!tab.id) throw new Error("Could not open SimCompanies API tab.");

  try {
    await waitForTabComplete(tab.id, 20000).catch(() => {});
    let lastError = "";
    for (let attempt = 1; attempt <= 12; attempt += 1) {
      try {
        const response = await sendTabMessage(tab.id, { type: "readJsonDocument" });
        if (response?.ok) return response.data;
        lastError = response?.error || "Could not read SimCompanies API data.";
        if (/browser-check|correct system time/i.test(lastError)) throw browserCheckError();
      } catch (error) {
        lastError = error?.message || "SimCompanies API reader is not ready.";
        if (/browser-check|correct system time/i.test(lastError)) throw browserCheckError();
      }
      await sleep(500);
    }
    throw new Error(lastError || "Timed out reading SimCompanies API data.");
  } finally {
    if (closeTab) await removeTab(tab.id).catch(() => {});
  }
}

async function fetchSimCompaniesJsonViaTab(url, options = {}) {
  if (url.includes("/api/v2/companies/me/buildings/")) {
    return fetchSimCompaniesJsonFromGamePage(url, options);
  }
  return fetchSimCompaniesJsonViaApiTab(url, options);
}

async function fetchOptionalSimCompaniesJsonViaTab(url, fallbackValue) {
  try {
    return await fetchSimCompaniesJsonViaTab(url);
  } catch (error) {
    console.warn(`Optional SimCompanies API tab fetch failed: ${url}`, error);
    return fallbackValue;
  }
}

async function fetchOptionalSimCompaniesJsonViaApiTab(url, fallbackValue) {
  try {
    return await fetchSimCompaniesJsonViaApiTab(url);
  } catch (error) {
    console.warn(`Optional SimCompanies API page parse failed: ${url}`, error);
    return fallbackValue;
  }
}

async function fetchBuildingsFromSimCompaniesTab() {
  const buildings = await fetchSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v2/companies/me/buildings/");
  return Array.isArray(buildings) ? buildings : [];
}

async function fetchOptionalBuildings() {
  try {
    return await fetchBuildingsFromSimCompaniesTab();
  } catch (error) {
    console.warn("Optional building status fetch failed", error);
    await updateJob({
      message: error?.message || "Open SimCompanies before syncing to include live building WIP.",
      currentItem: "buildings unavailable"
    });
    return [];
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForSimcotoolsSlot() {
  const minGapMs = 650;
  const now = Date.now();
  const waitMs = Math.max(0, lastSimcotoolsRequestAt + minGapMs - now);
  if (waitMs > 0) await sleep(waitMs);
  lastSimcotoolsRequestAt = Date.now();
}

async function fetchSimcotoolsJson(url) {
  await waitForSimcotoolsSlot();
  let response = await fetch(url, {
    credentials: "omit",
    headers: {
      accept: "application/json"
    }
  });

  if (response.status === 429) {
    await sleep(3000);
    await waitForSimcotoolsSlot();
    response = await fetch(url, {
      credentials: "omit",
      headers: {
        accept: "application/json"
      }
    });
  }

  if (!response.ok) throw new Error(`Simcotools fetch failed (${response.status})`);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch {
    throw friendlyFetchError(url, response, text);
  }
}

function extractMaxTimestamp(csvText) {
  const lines = csvText.trim().split(/\r?\n/);
  if (lines.length < 2) return 0;
  const header = lines[0].split(",");
  const timestampIndex = header.indexOf("Timestamp");
  if (timestampIndex === -1) return 0;
  return lines.slice(1).reduce((maxTimestamp, line) => {
    const raw = line.split(",")[timestampIndex];
    const timestamp = Date.parse(raw);
    return Number.isNaN(timestamp) ? maxTimestamp : Math.max(maxTimestamp, timestamp);
  }, 0);
}

async function fetchCompanyIds() {
  return fetchSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v2/players/me/companies/");
}

async function getCompanyForRealm(realmId) {
  const companies = await fetchCompanyIds();
  const match = (companies || []).find((company) => Number(company.realmId) === Number(realmId));
  const selected = match || companies?.[0];
  if (selected?.id) {
    const selectedRealm = Number(selected.realmId ?? selected.realm ?? realmId) || realmId;
    try {
      const details = await fetchSimcotoolsJson(`https://api.simcotools.com/v1/realms/${selectedRealm}/companies/${selected.id}`);
      const company = details.company || {};
      return {
        ...company,
        id: selected.id,
        name: company.name || selected.company || selected.name || `Company ${selected.id}`,
        logo: company.logo || selected.logo,
        realm: selectedRealm
      };
    } catch (error) {
      console.warn("Simcotools company profile lookup failed", error);
      return {
        id: selected.id,
        name: selected.company || selected.name || `Company ${selected.id}`,
        logo: selected.logo,
        realm: selectedRealm
      };
    }
  }
  throw new Error("No company id found. Make sure you are logged into SimCompanies.");
}

async function fetchResourceList(realmId) {
  const singlePageData = await fetchSimcotoolsJson(`https://api.simcotools.com/v1/realms/${realmId}/resources?type=all&disable_pagination=true`);
  if (Array.isArray(singlePageData.resources) && singlePageData.resources.length > 0) {
    return singlePageData.resources;
  }
  if (Array.isArray(singlePageData)) {
    return singlePageData;
  }

  const resources = [];
  let page = 1;
  while (true) {
    const data = await fetchSimcotoolsJson(`https://api.simcotools.com/v1/realms/${realmId}/resources?page=${page}`);
    resources.push(...(data.resources || []));
    const metadata = data.metadata || {};
    if ((metadata.currentPage || page) >= (metadata.lastPage || page)) break;
    page += 1;
  }
  return resources;
}

function normalizeBondRows(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.bonds)) return value.bonds;
  if (Array.isArray(value?.items)) return value.items;
  if (Array.isArray(value?.results)) return value.results;
  if (Array.isArray(value?.data)) return value.data;
  return [];
}

async function syncCompanyData(realmId, options = {}) {
  if (activeJob?.status === "running") return activeJob;
  const skipResourceHistory = Boolean(options.skipResourceHistory);

  activeJob = {
    id: Date.now(),
    status: "running",
    realmId,
    stage: "Starting",
    message: skipResourceHistory ? "Preparing planner sync" : "Preparing sync",
    currentItem: "",
    completed: 0,
    total: 10,
    resourceCompleted: 0,
    resourceTotal: 0,
    failed: 0,
    startedAt: Date.now(),
    updatedAt: Date.now()
  };
  await putStore(META_STORE, JOB_KEY, activeJob);

  const statements = {};
  const resourceHistory = {};
  let latestDataTimestamp = 0;

  try {
    await updateJob({ stage: "Account", message: "Finding company" });
    const companyProfile = await getCompanyForRealm(realmId);
    const companyId = companyProfile.id;

    for (const endpoint of STATEMENT_ENDPOINTS) {
      await updateJob({ stage: "Statements", message: `Fetching ${endpoint.name}`, currentItem: endpoint.name });
      const csv = await fetchCsv(endpoint.url);
      statements[endpoint.key] = csv;
      latestDataTimestamp = Math.max(latestDataTimestamp, extractMaxTimestamp(csv));
      await updateJob({ completed: activeJob.completed + 1 });
    }

    await updateJob({ stage: "Transactions", message: "Fetching account history", currentItem: "transactions.csv" });
    const transactionsCsv = await fetchCsv(`https://www.simcompanies.com/csv/account-history/${companyId}/`);
    statements.transactionsCsv = transactionsCsv;
    latestDataTimestamp = Math.max(latestDataTimestamp, extractMaxTimestamp(transactionsCsv));
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Inventory", message: "Fetching current inventory", currentItem: "inventory.json" });
    const inventory = await fetchSimCompaniesJsonViaTab(`https://www.simcompanies.com/api/v3/resources/${companyId}/`);
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Auth Data", message: "Fetching company modifiers", currentItem: "auth-data.json" });
    const companyAuthData = await fetchOptionalSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v3/companies/auth-data/", { authCompany: null });
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Bonds", message: "Fetching bond data", currentItem: "bonds sold/owned" });
    const [companyBondsSoldRaw, companyBondsOwnedRaw] = await Promise.all([
      fetchOptionalSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v2/companies/me/bonds/sold/", []),
      fetchOptionalSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v2/companies/me/bonds/owned/", [])
    ]);
    const companyBondsData = {
      sold: normalizeBondRows(companyBondsSoldRaw),
      owned: normalizeBondRows(companyBondsOwnedRaw)
    };
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Royalties", message: "Fetching royalty history", currentItem: "royalties.json" });
    const companyRoyalties = await fetchOptionalSimCompaniesJsonViaTab(`https://www.simcompanies.com/api/v2/companies/${companyId}/royalties/`, { royalties: null });
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Executives", message: "Fetching executives", currentItem: "executives.json" });
    const companyExecutives = await fetchOptionalSimCompaniesJsonViaTab(`https://www.simcompanies.com/api/v3/companies/${companyId}/executives/`, { executives: null });
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Research", message: "Fetching researched qualities", currentItem: "research.json" });
    const companyResearch = await fetchOptionalSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v3/players/research/", []);
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Buildings", message: "Fetching building status", currentItem: "buildings.json" });
    const buildings = await fetchOptionalBuildings();
    await updateJob({ completed: activeJob.completed + 1 });

    await updateJob({ stage: "Resources", message: "Loading resource list", currentItem: "resources" });
    const resources = await fetchResourceList(realmId);
    let failed = 0;
    if (skipResourceHistory) {
      await updateJob({
        completed: activeJob.completed + 1,
        resourceTotal: resources.length,
        resourceCompleted: 0,
        message: "Planner sync skipped resource history files",
        currentItem: "resource histories skipped"
      });
    } else {
      await updateJob({
        total: activeJob.total + resources.length,
        resourceTotal: resources.length,
        resourceCompleted: 0,
        message: `Fetching resource histories: 0/${resources.length}`
      });

      const concurrency = 4;
      let index = 0;
      async function worker() {
        while (index < resources.length) {
          const resource = resources[index++];
          try {
            await updateJob({ currentItem: resource.name || `Resource ${resource.id}` });
            resourceHistory[String(resource.id)] = await fetchCsv(`https://www.simcompanies.com/csv/resource-history/${resource.id}/`);
          } catch (error) {
            failed += 1;
            console.warn(`Resource ${resource.id} failed`, error);
          } finally {
            await updateJob({
              completed: activeJob.completed + 1,
              resourceCompleted: (activeJob.resourceCompleted || 0) + 1,
              failed,
              message: `Fetching resource histories: ${(activeJob.resourceCompleted || 0) + 1}/${resources.length}`
            });
          }
        }
      }

      await Promise.all(Array.from({ length: concurrency }, () => worker()));
    }

    const bundle = {
      version: 1,
      realmId,
      companyId,
      companyProfile,
      exportedAt: new Date().toISOString(),
      latestDataTimestamp,
      statements,
      inventory,
      companyAuthData,
      companyBondsData,
      companyRoyalties,
      companyExecutives,
      companyResearch,
      buildings,
      resources,
      resourceHistory
    };
    await putStore(BUNDLE_STORE, LATEST_BUNDLE_KEY, bundle);
    await chrome.storage.local.set({ latestBundleSummary: summarizeBundle(bundle) });
    await updateJob({
      status: "complete",
      stage: "Complete",
      message: skipResourceHistory ? "Planner sync complete" : failed ? `Sync complete with ${failed} resource errors` : "Sync complete",
      currentItem: "",
      finishedAt: Date.now()
    });
  } catch (error) {
    await updateJob({
      status: "error",
      stage: "Failed",
      message: error?.message || "Sync failed",
      currentItem: ""
    });
  }

  return activeJob;
}

async function startSyncAndReturnBundle(realmId, options = {}) {
  const job = await syncCompanyData(realmId, options);
  if (job?.status !== "complete") {
    return {
      ok: false,
      job,
      error: job?.message || "Sync did not complete."
    };
  }

  const bundle = await getStore(BUNDLE_STORE, LATEST_BUNDLE_KEY);
  if (!bundle) {
    return {
      ok: false,
      job,
      error: "Sync completed, but no planner bundle was saved."
    };
  }

  let analytics = { ok: true, skipped: true };
  if (options.analytics) {
    analytics = await logToolSyncAnalytics(options.analytics, bundle).catch((error) => ({
      ok: false,
      error: error?.message || "Analytics logging failed."
    }));
  }

  return { ok: true, job, bundle, analytics };
}

function summarizeBundle(bundle) {
  return {
    version: bundle.version,
    realmId: bundle.realmId,
    companyId: bundle.companyId,
    companyName: bundle.companyProfile?.name,
    companyLogo: bundle.companyProfile?.logo,
    exportedAt: bundle.exportedAt,
    latestDataTimestamp: bundle.latestDataTimestamp,
    resourceCount: bundle.resources?.length || 0,
    resourceHistoryCount: Object.keys(bundle.resourceHistory || {}).length
  };
}

function syncAnalyticsSummary(bundle) {
  return {
    exportedAt: bundle.exportedAt,
    resourceHistoryCount: Object.keys(bundle.resourceHistory || {}).length,
    resourceCount: Array.isArray(bundle.resources) ? bundle.resources.length : 0,
    buildingCount: Array.isArray(bundle.buildings) ? bundle.buildings.length : 0,
    inventoryCount: Array.isArray(bundle.inventory) ? bundle.inventory.length : 0,
    priceCount: 0,
    extensionLogged: true,
    authCompany: bundle.companyAuthData?.authCompany
      ? {
        level: bundle.companyAuthData.authCompany.level,
        rank: bundle.companyAuthData.authCompany.rank,
        value: bundle.companyAuthData.authCompany.value,
        money: bundle.companyAuthData.authCompany.money,
        simBoosts: bundle.companyAuthData.authCompany.simBoosts,
        productionModifier: bundle.companyAuthData.authCompany.productionModifier,
        salesModifier: bundle.companyAuthData.authCompany.salesModifier
      }
      : null
  };
}

async function logToolSyncAnalytics(config, bundle) {
  const supabaseUrl = String(config.supabaseUrl || "").replace(/\/+$/, "");
  const supabaseAnonKey = String(config.supabaseAnonKey || "");
  const sessionToken = String(config.sessionToken || "");
  const realmId = Number(config.realmId ?? bundle.realmId);
  const companyId = Number(config.companyId ?? bundle.companyId);

  if (!supabaseUrl || !supabaseAnonKey || !sessionToken || !Number.isFinite(companyId)) {
    return { ok: true, skipped: true };
  }

  const statements = bundle.statements || {};
  const response = await fetch(`${supabaseUrl}/rest/v1/rpc/log_tool_sync`, {
    method: "POST",
    headers: {
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${supabaseAnonKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      p_realm_id: realmId,
      p_company_id: companyId,
      p_session_token: sessionToken,
      p_company_name: bundle.companyProfile?.name || config.companyName || "Unknown company",
      p_company_logo: bundle.companyProfile?.logo || config.companyLogo || null,
      p_client_exported_at: bundle.exportedAt || null,
      p_app_version: config.appVersion || null,
      p_summary: syncAnalyticsSummary(bundle),
      p_executives_json: bundle.companyExecutives || null,
      p_buildings_json: bundle.buildings || null,
      p_inventory_json: bundle.inventory || null,
      p_auth_json: bundle.companyAuthData || null,
      p_bonds_json: bundle.companyBondsData || null,
      p_royalties_json: bundle.companyRoyalties || null,
      p_income_csv: statements.incomeCsv || null,
      p_balance_csv: statements.balanceCsv || null,
      p_cashflow_csv: statements.cashflowCsv || null,
      p_transactions_csv: statements.transactionsCsv || null,
      p_resource_history_json: bundle.resourceHistory || null,
      p_resources_json: bundle.resources || null
    })
  });

  if (!response.ok) {
    let message = `Analytics logging failed (${response.status})`;
    try {
      const data = await response.json();
      message = data?.message || data?.error || message;
    } catch {
      const text = await response.text().catch(() => "");
      message = text || message;
    }
    throw new Error(message);
  }

  return { ok: true };
}

async function getPublicState() {
  const [job, bundle, storage, local] = await Promise.all([
    getStore(META_STORE, JOB_KEY).catch(() => null),
    getStore(BUNDLE_STORE, LATEST_BUNDLE_KEY).catch(() => null),
    chrome.storage.sync.get({ realmId: 0 }),
    chrome.storage.local.get({ latestBundleSummary: null })
  ]);
  return {
    ok: true,
    job,
    summary: bundle ? summarizeBundle(bundle) : local.latestBundleSummary,
    realmId: Number(storage.realmId) || 0
  };
}

async function refreshCompanyProfileOnly(realmId) {
  const companyProfile = await getCompanyForRealm(realmId);
  const bundle = await getStore(BUNDLE_STORE, LATEST_BUNDLE_KEY).catch(() => null);
  if (!bundle) {
    const summary = {
      realmId,
      companyId: companyProfile.id,
      companyName: companyProfile.name,
      companyLogo: companyProfile.logo,
      resourceCount: 0,
      resourceHistoryCount: 0
    };
    await chrome.storage.local.set({
      latestBundleSummary: summary
    });
    return { ok: true, companyProfile, summary };
  }

  const nextBundle = {
    ...bundle,
    companyId: companyProfile.id,
    companyProfile
  };
  await putStore(BUNDLE_STORE, LATEST_BUNDLE_KEY, nextBundle);
  const summary = summarizeBundle(nextBundle);
  await chrome.storage.local.set({ latestBundleSummary: summary });
  return { ok: true, companyProfile, summary };
}

function resourceSlug(name) {
  return String(name || "")
    .trim()
    .toLowerCase()
    .replace(/['’]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function resourceDisplayName(resource) {
  return resource?.name ?? resource?.resourceName ?? resource?.resource_name ?? resource?.displayName ?? "";
}

function resourceDisplayId(resource) {
  return Number(resource?.id ?? resource?.kind ?? resource?.resourceId ?? resource?.resource_id) || 0;
}

function normalizeInventoryStock(inventory, resourceNames = new Map()) {
  const rows = Array.isArray(inventory)
    ? inventory
    : Array.isArray(inventory?.resources)
      ? inventory.resources
      : Array.isArray(inventory?.data)
        ? inventory.data
        : Array.isArray(inventory?.items)
          ? inventory.items
          : [];
  return rows
    .map((item) => {
      const resourceId = Number(item.kind ?? item.resourceId ?? item.resource?.kind ?? item.resource?.id) || 0;
      return {
        resourceId,
        resourceName: String(item.name ?? item.resourceName ?? item.resource?.name ?? resourceNames.get(resourceId) ?? `Resource ${resourceId}`),
        quality: Number(item.quality) || 0,
        quantity: Number(item.amount ?? item.quantity) || 0,
        blocked: Boolean(item.blocked)
      };
    })
    .filter((item) => item.resourceId && item.quantity > 0);
}

function simcotoolsMarketRows(data) {
  if (Array.isArray(data)) return data;
  if (!data || typeof data !== "object") return [];
  const candidates = [
    data.markets,
    data.market,
    data.data,
    data.prices,
    data.resource?.markets,
    data.resource?.market,
    data.resource?.prices,
    data.resource?.summariesByQuality,
    data.summariesByQuality
  ];
  const array = candidates.find(Array.isArray);
  return Array.isArray(array) ? array : [];
}

function simcotoolsMarketPrice(row) {
  const latestClose = Array.isArray(row.latestClosePrices) ? row.latestClosePrices.at(-1)?.closePrice : undefined;
  const vwap = Number(
    row.vwap ??
    row.VWAP ??
    row.vwapPrice ??
    row.averagePrice ??
    row.meanPrice ??
    row.lastDayCandlestick?.vwap ??
    row.fiveMinutesCandlestick?.vwap
  );
  const exchangePrice = Number(
    row.price ??
    row.close ??
    row.ask ??
    row.sellPrice ??
    row.marketPrice ??
    row.averagePrice ??
    row.fiveMinutesCandlestick?.close ??
    latestClose ??
    row.lastDayCandlestick?.close ??
    row.vwap
  );
  return {
    quality: Number(row.quality ?? row.qualityLevel ?? row.q ?? 0),
    vwap: Number.isFinite(vwap) && vwap > 0 ? vwap : 0,
    exchangePrice: Number.isFinite(exchangePrice) && exchangePrice > 0
      ? exchangePrice
      : Number.isFinite(vwap) && vwap > 0
        ? vwap
        : 0
  };
}

async function fetchTradingMarketMap(realmId, stock) {
  const resourceIds = [...new Set(stock.map((item) => item.resourceId).filter(Boolean))];
  const prices = new Map();
  for (const resourceId of resourceIds) {
    try {
      const data = await fetchSimcotoolsJson(`https://api.simcotools.com/v1/realms/${realmId}/market/resources/${resourceId}`);
      for (const row of simcotoolsMarketRows(data)) {
        const price = simcotoolsMarketPrice(row);
        if (!price.vwap && !price.exchangePrice) continue;
        prices.set(`${resourceId}:${price.quality}`, price);
      }
    } catch (error) {
      console.warn(`Trading market price lookup failed for resource ${resourceId}`, error);
    }
  }
  return prices;
}

async function getTradingMarketPrices(realmId, items = []) {
  const stock = items
    .map((item) => ({
      resourceId: Number(item.resourceId),
      quality: Number(item.quality)
    }))
    .filter((item) => Number.isFinite(item.resourceId) && Number.isFinite(item.quality));
  const marketPrices = await fetchTradingMarketMap(realmId, stock);
  return {
    ok: true,
    prices: stock.map((item) => {
      const market = marketPrices.get(`${item.resourceId}:${item.quality}`);
      return {
        resourceId: item.resourceId,
        quality: item.quality,
        vwap: market?.vwap ?? 0,
        exchangePrice: market?.exchangePrice ?? market?.vwap ?? 0
      };
    })
  };
}

async function getTradingSnapshot(realmId) {
  const cached = cachedTradingSnapshot;
  if (
    cached?.snapshot?.realmId === realmId &&
    Date.now() - new Date(cached.snapshot.exportedAt).getTime() < 30000
  ) {
    return cached.response;
  }

  if (activeTradingSnapshot?.realmId === realmId) {
    return activeTradingSnapshot.promise;
  }

  const promise = buildTradingSnapshot(realmId);
  activeTradingSnapshot = { realmId, promise };
  try {
    const response = await promise;
    cachedTradingSnapshot = { response, snapshot: response.snapshot };
    return response;
  } finally {
    if (activeTradingSnapshot?.promise === promise) activeTradingSnapshot = null;
  }
}

async function buildTradingSnapshot(realmId) {
  const companyProfile = await getCompanyForRealm(realmId);
  const [inventory, resources] = await Promise.all([
    fetchSimCompaniesJsonViaTab(`https://www.simcompanies.com/api/v3/resources/${companyProfile.id}/`),
    fetchResourceList(realmId).catch(() => [])
  ]);
  const resourceNames = new Map(
    (resources || [])
      .map((resource) => [resourceDisplayId(resource), resourceDisplayName(resource)])
      .filter(([id, name]) => Number.isFinite(id) && name)
  );
  const stock = normalizeInventoryStock(inventory, resourceNames);
  const marketPrices = await fetchTradingMarketMap(realmId, stock);
  const pricedStock = stock.map((item) => {
    const market = marketPrices.get(`${item.resourceId}:${item.quality}`);
    return {
      ...item,
      vwap: market?.vwap ?? 0,
      exchangePrice: market?.exchangePrice ?? market?.vwap ?? 0
    };
  });
  const snapshot = {
    version: 1,
    realmId,
    companyId: companyProfile.id,
    companyProfile,
    exportedAt: new Date().toISOString(),
    stock: pricedStock,
    debug: {
      inventoryShape: Array.isArray(inventory)
        ? "array"
        : inventory && typeof inventory === "object"
          ? Object.keys(inventory).join(",")
          : typeof inventory,
      rawRows: Array.isArray(inventory)
        ? inventory.length
        : Array.isArray(inventory?.resources)
          ? inventory.resources.length
          : Array.isArray(inventory?.data)
            ? inventory.data.length
            : Array.isArray(inventory?.items)
              ? inventory.items.length
              : 0,
      normalizedRows: stock.length,
      pricedRows: pricedStock.filter((item) => item.exchangePrice || item.vwap).length
    }
  };
  await chrome.storage.local.set({ latestTradingSnapshot: snapshot });
  return { ok: true, snapshot };
}

function firstContractArray(payload) {
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== "object") return [];
  for (const key of ["contracts", "items", "rows", "results", "data"]) {
    if (Array.isArray(payload[key])) return payload[key];
  }
  for (const value of Object.values(payload)) {
    if (Array.isArray(value)) return value;
  }
  return [];
}

function contractNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return 0;
}

function contractText(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
    if (value && typeof value === "object") {
      for (const key of ["company", "name", "companyName", "username"]) {
        if (typeof value[key] === "string" && value[key].trim()) return value[key].trim();
      }
    }
  }
  return "";
}

function normalizeContractRows(payload, side) {
  return firstContractArray(payload).map((row) => {
    const details = row?.details && typeof row.details === "object" ? row.details : {};
    const resource = row?.resource && typeof row.resource === "object" ? row.resource : {};
    const otherCompany = side === "incoming"
      ? contractText(row?.seller, row?.sender, row?.from, row?.company, row?.otherParty, row?.issuer, row?.counterparty)
      : contractText(row?.buyer, row?.recipient, row?.to, row?.company, row?.otherParty, row?.counterparty);
    return {
      id: String(row?.id ?? row?.contractId ?? row?.uuid ?? `${side}-${Math.random().toString(36).slice(2)}`),
      side,
      resourceId: contractNumber(row?.resourceId, row?.kind, details.resource, details.kind, resource.kind, resource.id),
      resourceName: contractText(row?.resourceName, resource.name, row?.name),
      quality: contractNumber(row?.quality, details.quality, resource.quality),
      amount: contractNumber(row?.amount, row?.quantity, details.amount, resource.amount),
      price: contractNumber(row?.price, row?.unitPrice, details.price, resource.price),
      companyName: otherCompany,
      createdAt: contractText(row?.datetime, row?.createdAt, row?.created, row?.date, row?.timestamp),
    };
  });
}

async function getTradingContracts(realmId) {
  const realm = Number(realmId) || 0;
  const [incomingResult, outgoingResult] = await Promise.allSettled([
    fetchSimCompaniesJsonViaTab(`https://www.simcompanies.com/api/v3/contracts-incoming/${realm}/me/`),
    fetchSimCompaniesJsonViaTab("https://www.simcompanies.com/api/v3/contracts-outgoing/me/")
  ]);
  const incoming = incomingResult.status === "fulfilled" ? normalizeContractRows(incomingResult.value, "incoming") : [];
  const outgoing = outgoingResult.status === "fulfilled" ? normalizeContractRows(outgoingResult.value, "outgoing") : [];
  return {
    ok: incomingResult.status === "fulfilled" || outgoingResult.status === "fulfilled",
    incoming,
    outgoing,
    incomingError: incomingResult.status === "rejected" ? incomingResult.reason?.message || "Incoming contracts failed." : "",
    outgoingError: outgoingResult.status === "rejected" ? outgoingResult.reason?.message || "Outgoing contracts failed." : "",
  };
}

function waitForTabComplete(tabId, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Timed out waiting for SimCompanies contract page to load."));
    }, timeoutMs);

    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId || changeInfo.status !== "complete") return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };

    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function sendTabMessageWithRetry(tabId, message, attempts = 20) {
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = await sendTabMessage(tabId, message);
      if (response?.ok) return response;
      lastError = new Error(response?.error || "Contract draft fill failed.");
    } catch (error) {
      lastError = error;
    }
    await sleep(500);
  }
  throw lastError || new Error("Contract draft fill failed.");
}

async function openContractDraft({ resourceName, resourceSlug: explicitSlug, recipient, amount, price }) {
  const slug = explicitSlug || resourceSlug(resourceName);
  if (!slug) throw new Error("Missing resource for contract draft.");
  if (!recipient || !amount || !price) throw new Error("Missing contract draft details.");

  const url = `https://www.simcompanies.com/headquarters/warehouse/${slug}/contract/`;
  const tab = await chrome.tabs.create({ url, active: true });
  if (!tab.id) throw new Error("Could not open SimCompanies contract page.");
  await waitForTabComplete(tab.id).catch(() => {});
  return sendTabMessageWithRetry(tab.id, {
    type: "fillContractDraft",
    recipient,
    amount,
    price
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message?.type) return false;

  if (message.type === "startSync") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    startSyncAndReturnBundle(realmId, { skipResourceHistory: Boolean(message.skipResourceHistory) })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Sync failed" }));
    return true;
  }

  if (message.type === "getState") {
    getPublicState().then(sendResponse);
    return true;
  }

  if (message.type === "refreshCompanyProfile") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    refreshCompanyProfileOnly(realmId)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Profile refresh failed" }));
    return true;
  }

  if (message.type === "openSimCompanies") {
    openSimCompaniesTab()
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Could not open SimCompanies" }));
    return true;
  }

  if (message.type === "getLatestBundle") {
    getStore(BUNDLE_STORE, LATEST_BUNDLE_KEY)
      .then((bundle) => sendResponse({ ok: true, bundle }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Bundle read failed" }));
    return true;
  }

  if (message.type === "getTradingSnapshot") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingSnapshot(realmId)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading snapshot failed" }));
    return true;
  }

  if (message.type === "getTradingMarketPrices") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingMarketPrices(realmId, message.items)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading market price lookup failed" }));
    return true;
  }

  if (message.type === "getTradingContracts") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingContracts(realmId)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading contract lookup failed" }));
    return true;
  }

  if (message.type === "openContractDraft") {
    openContractDraft(message)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Could not open contract draft" }));
    return true;
  }

  return false;
});

chrome.runtime.onMessageExternal.addListener((message, _sender, sendResponse) => {
  if (!message?.type) return false;

  if (message.type === "simcoAnalyzer.getState") {
    getPublicState().then(sendResponse);
    return true;
  }

  if (message.type === "simcoAnalyzer.getLatestBundle") {
    getStore(BUNDLE_STORE, LATEST_BUNDLE_KEY)
      .then((bundle) => sendResponse({ ok: true, bundle }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Bundle read failed" }));
    return true;
  }

  if (message.type === "simcoAnalyzer.startSync") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    startSyncAndReturnBundle(realmId, { skipResourceHistory: Boolean(message.skipResourceHistory) })
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Sync failed" }));
    return true;
  }

  if (message.type === "simcoAnalyzer.getTradingSnapshot") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingSnapshot(realmId)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading snapshot failed" }));
    return true;
  }

  if (message.type === "simcoAnalyzer.getTradingMarketPrices") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingMarketPrices(realmId, message.items)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading market price lookup failed" }));
    return true;
  }

  if (message.type === "simcoAnalyzer.getTradingContracts") {
    const realmId = Number(message.realmId) || 0;
    chrome.storage.sync.set({ realmId });
    getTradingContracts(realmId)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Trading contract lookup failed" }));
    return true;
  }

  if (message.type === "simcoAnalyzer.openContractDraft") {
    openContractDraft(message)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Could not open contract draft" }));
    return true;
  }

  return false;
});
