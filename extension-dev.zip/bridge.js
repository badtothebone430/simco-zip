const PAGE_SOURCE = "simco-analyzer-page";
const EXTENSION_SOURCE = "simco-analyzer-extension";

const messageMap = {
  "simcoAnalyzer.getLatestBundle": "getLatestBundle",
  "simcoAnalyzer.getState": "getState",
  "simcoAnalyzer.startSync": "startSync",
  "simcoAnalyzer.getTradingSnapshot": "getTradingSnapshot",
  "simcoAnalyzer.getTradingMarketPrices": "getTradingMarketPrices",
  "simcoAnalyzer.getTradingContracts": "getTradingContracts",
  "simcoAnalyzer.openContractDraft": "openContractDraft"
};

window.postMessage({
  source: EXTENSION_SOURCE,
  type: "simcoAnalyzer.available"
}, window.location.origin);

window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (event.origin !== window.location.origin) return;

  const message = event.data;
  if (!message || message.source !== PAGE_SOURCE || message.type !== "simcoAnalyzer.request") return;

  const requestId = message.requestId;
  const runtimeType = messageMap[message.action];

  if (!requestId || !runtimeType) {
    window.postMessage({
      source: EXTENSION_SOURCE,
      type: "simcoAnalyzer.response",
      requestId,
      response: { ok: false, extensionId: globalThis.chrome?.runtime?.id, error: "Unsupported DevTools Helper action." }
    }, window.location.origin);
    return;
  }

  const runtime = globalThis.chrome?.runtime;
  if (!runtime?.sendMessage) {
    window.postMessage({
      source: EXTENSION_SOURCE,
      type: "simcoAnalyzer.response",
      requestId,
      response: { ok: false, extensionId: runtime?.id, error: "DevTools Helper runtime is unavailable. Reload the helper, then refresh this page." }
    }, window.location.origin);
    return;
  }

  try {
    runtime.sendMessage({ type: runtimeType, ...(message.payload || {}) }, (response) => {
      const lastError = runtime.lastError;
      window.postMessage({
        source: EXTENSION_SOURCE,
        type: "simcoAnalyzer.response",
        requestId,
        response: {
          ...(lastError?.message ? { ok: false, error: lastError.message } : response),
          extensionId: runtime.id
        }
      }, window.location.origin);
    });
  } catch (error) {
    window.postMessage({
      source: EXTENSION_SOURCE,
      type: "simcoAnalyzer.response",
      requestId,
      response: {
        ok: false,
        extensionId: runtime?.id,
        error: error?.message?.includes("context invalidated")
          ? "DevTools Helper was reloaded. Refresh this page, then try again."
          : error?.message || "DevTools Helper request failed."
      }
    }, window.location.origin);
  }
});
