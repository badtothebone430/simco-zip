const realms = {
  0: "Magnates",
  1: "Entrepreneurs"
};

const elements = {
  realm: document.getElementById("realm"),
  sync: document.getElementById("sync"),
  plannerSync: document.getElementById("plannerSync"),
  refreshProfile: document.getElementById("refreshProfile"),
  openSimCompanies: document.getElementById("openSimCompanies"),
  stage: document.getElementById("stage"),
  progressText: document.getElementById("progressText"),
  progressFill: document.getElementById("progressFill"),
  item: document.getElementById("item"),
  status: document.getElementById("status"),
  companyName: document.getElementById("companyName"),
  exportedAt: document.getElementById("exportedAt"),
  resourceCount: document.getElementById("resourceCount"),
  historyCount: document.getElementById("historyCount"),
  bundleRealm: document.getElementById("bundleRealm"),
  extensionId: document.getElementById("extensionId"),
  copyExtensionId: document.getElementById("copyExtensionId")
};

function formatDate(value) {
  if (!value) return "Never";
  return new Date(value).toLocaleString();
}

function progressPercent(job) {
  if (!job?.total) return 0;
  return Math.max(0, Math.min(100, Math.round((job.completed / job.total) * 100)));
}

function renderJob(job) {
  const percent = progressPercent(job);
  const running = job?.status === "running";
  elements.stage.textContent = job?.stage || "Ready";
  elements.progressText.textContent = job ? `${percent}%` : "Idle";
  elements.progressFill.style.width = `${percent}%`;
  elements.item.textContent = job?.currentItem || job?.message || "Run a sync to prepare analyzer data.";
  elements.status.textContent = job?.message || "Ready";
  elements.status.className = `status ${job?.status === "error" ? "err" : job?.status === "complete" ? "ok" : ""}`.trim();
  elements.sync.disabled = running;
  elements.plannerSync.disabled = running;
  elements.refreshProfile.disabled = running;
  elements.openSimCompanies.classList.toggle("hidden", !/open simcompanies/i.test(job?.message || ""));
}

function renderSummary(summary) {
  elements.companyName.textContent = summary?.companyName || "-";
  elements.exportedAt.textContent = formatDate(summary?.exportedAt);
  elements.resourceCount.textContent = String(summary?.resourceCount ?? 0);
  elements.historyCount.textContent = String(summary?.resourceHistoryCount ?? 0);
  elements.bundleRealm.textContent = summary ? realms[summary.realmId] : "-";
}

async function refreshState() {
  const state = await chrome.runtime.sendMessage({ type: "getState" });
  if (!state?.ok) return;
  elements.realm.value = String(state.realmId ?? 0);
  renderJob(state.job);
  renderSummary(state.summary);
}

async function startSync() {
  const realmId = Number(elements.realm.value) || 0;
  elements.sync.disabled = true;
  const response = await chrome.runtime.sendMessage({ type: "startSync", realmId });
  if (!response?.ok) {
    elements.status.textContent = response?.error || "Sync failed to start";
    elements.status.className = "status err";
  }
  await refreshState();
}

async function startPlannerSync() {
  const realmId = Number(elements.realm.value) || 0;
  elements.plannerSync.disabled = true;
  const response = await chrome.runtime.sendMessage({ type: "startSync", realmId, skipResourceHistory: true });
  if (!response?.ok) {
    elements.status.textContent = response?.error || "Planner sync failed to start";
    elements.status.className = "status err";
  }
  await refreshState();
}

async function refreshProfile() {
  const realmId = Number(elements.realm.value) || 0;
  elements.refreshProfile.disabled = true;
  elements.status.textContent = "Refreshing company profile...";
  elements.status.className = "status";
  const response = await chrome.runtime.sendMessage({ type: "refreshCompanyProfile", realmId });
  if (!response?.ok) {
    elements.status.textContent = response?.error || "Profile refresh failed";
    elements.status.className = "status err";
  } else {
    elements.status.textContent = "Company profile refreshed";
    elements.status.className = "status ok";
  }
  await refreshState();
  elements.refreshProfile.disabled = false;
}

async function openSimCompanies() {
  const response = await chrome.runtime.sendMessage({ type: "openSimCompanies" });
  if (!response?.ok) {
    elements.status.textContent = response?.error || "Could not open SimCompanies";
    elements.status.className = "status err";
  }
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "syncProgress") {
    renderJob(message.job);
  }
});

elements.sync.addEventListener("click", startSync);
elements.plannerSync.addEventListener("click", startPlannerSync);
elements.refreshProfile.addEventListener("click", refreshProfile);
elements.openSimCompanies.addEventListener("click", openSimCompanies);
elements.extensionId.textContent = chrome.runtime.id;
elements.copyExtensionId.addEventListener("click", async () => {
  await navigator.clipboard.writeText(chrome.runtime.id);
  elements.copyExtensionId.textContent = "Copied";
  window.setTimeout(() => {
    elements.copyExtensionId.textContent = "Copy ID";
  }, 1400);
});
elements.realm.addEventListener("change", async () => {
  await chrome.storage.sync.set({ realmId: Number(elements.realm.value) || 0 });
});

refreshState();
setInterval(refreshState, 1000);
