const PAGE_RESPONSE_SOURCE = "simco-analyzer-simcompanies-page";
let helperInjected = false;

function isBrowserCheckResponse(text) {
  const body = String(text || "").trim().toLowerCase();
  return (
    /^\s*<!doctype html/i.test(text || "") ||
    /^\s*<html/i.test(text || "") ||
    body.includes("just a moment") ||
    body.includes("correct system time") ||
    body.includes("make sure your device has the correct system time")
  );
}

function ensurePageHelper() {
  if (helperInjected) return;
  helperInjected = true;
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("simcompanies-page.js");
  script.onload = () => script.remove();
  script.onerror = () => {
    helperInjected = false;
  };
  (document.documentElement || document.head || document.body).appendChild(script);
}

function requestCachedBuildings() {
  return new Promise((resolve, reject) => {
    ensurePageHelper();

    const requestId = `buildings-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let finished = false;

    const cleanup = () => {
      window.clearTimeout(timeout);
      window.removeEventListener("message", onMessage);
    };

    const finish = (callback, value) => {
      if (finished) return;
      finished = true;
      cleanup();
      callback(value);
    };

    const onMessage = (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const data = event.data;
      if (!data || data.source !== PAGE_RESPONSE_SOURCE || data.type !== "buildingsResponse" || data.requestId !== requestId) return;
      if (data.ok) finish(resolve, Array.isArray(data.buildings) ? data.buildings : []);
      else finish(reject, new Error(data.error || "Building status has not loaded yet."));
    };

    const timeout = window.setTimeout(() => {
      finish(reject, new Error("Timed out waiting for SimCompanies to load building status. Open the Landscape page and try sync again."));
    }, 20000);

    window.addEventListener("message", onMessage);
    window.postMessage(
      {
        source: "simco-analyzer-extension",
        type: "getCachedBuildings",
        requestId,
      },
      window.location.origin,
    );
  });
}

function requestCapturedJson(url) {
  return new Promise((resolve, reject) => {
    ensurePageHelper();

    const requestId = `capture-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    let finished = false;

    const cleanup = () => {
      window.clearTimeout(timeout);
      window.removeEventListener("message", onMessage);
    };

    const finish = (callback, value) => {
      if (finished) return;
      finished = true;
      cleanup();
      callback(value);
    };

    const onMessage = (event) => {
      if (event.source !== window || event.origin !== window.location.origin) return;
      const data = event.data;
      if (!data || data.source !== PAGE_RESPONSE_SOURCE || data.type !== "capturedJsonResponse" || data.requestId !== requestId) return;
      if (data.ok) finish(resolve, data.data);
      else finish(reject, new Error(data.error || "SimCompanies API data was not captured from the official page."));
    };

    const timeout = window.setTimeout(() => {
      finish(reject, new Error("Timed out waiting for the official SimCompanies page to call the API."));
    }, 35000);

    window.addEventListener("message", onMessage);
    window.postMessage(
      {
        source: "simco-analyzer-extension",
        type: "getCapturedJson",
        requestId,
        url,
      },
      window.location.origin,
    );
  });
}

ensurePageHelper();

function setInputValue(input, value) {
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
  if (setter) setter.call(input, String(value));
  else input.value = String(value);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}

function waitForSelector(selector, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const existing = document.querySelector(selector);
    if (existing) {
      resolve(existing);
      return;
    }

    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (!element) return;
      window.clearTimeout(timeout);
      observer.disconnect();
      resolve(element);
    });

    const timeout = window.setTimeout(() => {
      observer.disconnect();
      reject(new Error(`Timed out waiting for ${selector}.`));
    }, timeoutMs);

    observer.observe(document.documentElement || document.body, {
      childList: true,
      subtree: true
    });
  });
}

async function fillContractDraft({ recipient, amount, price }) {
  const [recipientInput, amountInput, priceInput] = await Promise.all([
    waitForSelector('input[name="recipientLookup"]'),
    waitForSelector('input[name="amount"]'),
    waitForSelector('input[name="price"]')
  ]);

  setInputValue(recipientInput, recipient);
  setInputValue(amountInput, amount);
  setInputValue(priceInput, price);
  recipientInput.focus();

  return {
    ok: true,
    message: "Contract draft filled. Review it in SimCompanies before sending."
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "readJsonDocument") {
    try {
      const text = document.body?.innerText || document.documentElement?.innerText || "";
      const trimmed = text.trim();
      if (!trimmed) {
        sendResponse({ ok: false, error: "The SimCompanies API page did not return any readable data." });
        return true;
      }
      if (isBrowserCheckResponse(trimmed)) {
        sendResponse({ ok: false, error: "SimCompanies returned its browser-check page instead of JSON. Open or refresh SimCompanies until the game loads normally, then try again." });
        return true;
      }
      sendResponse({ ok: true, data: JSON.parse(trimmed) });
    } catch (error) {
      sendResponse({ ok: false, error: error?.message || "Could not read the SimCompanies API page." });
    }
    return true;
  }

  if (message?.type === "fetchBuildingsFromPage") {
    requestCachedBuildings()
      .then((buildings) => sendResponse({ ok: true, buildings }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Building status fetch failed." }));

    return true;
  }

  if (message?.type === "getCapturedJsonFromPage") {
    requestCapturedJson(message.url)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || "SimCompanies API capture failed." }));
    return true;
  }

  if (message?.type === "fillContractDraft") {
    fillContractDraft(message)
      .then(sendResponse)
      .catch((error) => sendResponse({ ok: false, error: error?.message || "Contract draft fill failed." }));
    return true;
  }

  return false;
});
