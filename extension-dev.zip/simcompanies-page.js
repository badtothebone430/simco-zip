(() => {
  if (window.__simcoAnalyzerApiCaptureHooked) return;
  window.__simcoAnalyzerApiCaptureHooked = true;

  const responseSource = "simco-analyzer-simcompanies-page";
  const requestSource = "simco-analyzer-extension";
  const buildingsPath = "/api/v2/companies/me/buildings/";

  let cachedBuildings = null;
  let cachedAt = 0;
  const capturedJson = new Map();
  const pendingCaptureRequests = [];

  const captureKeyForUrl = (input) => {
    const raw = typeof input === "string" ? input : input?.url || "";
    if (!raw) return "";
    try {
      const url = new URL(raw, window.location.origin);
      return `${url.pathname}${url.search}`;
    } catch {
      return raw;
    }
  };

  const isBuildingsUrl = (input) => captureKeyForUrl(input).startsWith(buildingsPath);

  const cacheBuildings = (data) => {
    if (!Array.isArray(data)) return;
    cachedBuildings = data;
    cachedAt = Date.now();
    window.postMessage(
      {
        source: responseSource,
        type: "buildingsCaptured",
        ok: true,
        buildings: cachedBuildings,
        cachedAt,
      },
      window.location.origin,
    );
  };

  const postCaptureResponse = (requestId, payload) => {
    window.postMessage(
      {
        source: responseSource,
        type: "capturedJsonResponse",
        requestId,
        ...payload,
      },
      window.location.origin,
    );
  };

  const captureJson = (input, data) => {
    const key = captureKeyForUrl(input);
    if (!key) return;

    const row = {
      data,
      capturedAt: Date.now(),
      url: key,
    };
    capturedJson.set(key, row);
    if (isBuildingsUrl(input)) cacheBuildings(data);

    for (let index = pendingCaptureRequests.length - 1; index >= 0; index -= 1) {
      const pending = pendingCaptureRequests[index];
      if (!pending.matches(key)) continue;
      window.clearTimeout(pending.timeout);
      pendingCaptureRequests.splice(index, 1);
      postCaptureResponse(pending.requestId, {
        ok: true,
        data: row.data,
        capturedAt: row.capturedAt,
        capturedUrl: row.url,
      });
    }
  };

  const parseAndCapture = (input, text) => {
    try {
      const data = JSON.parse(text || "null");
      captureJson(input, data);
    } catch {
      // Ignore non-JSON responses.
    }
  };

  const originalFetch = window.fetch;
  if (typeof originalFetch === "function") {
    window.fetch = async function patchedFetch(...args) {
      const response = await originalFetch.apply(this, args);
      response
        .clone()
        .text()
        .then((text) => parseAndCapture(args[0], text))
        .catch(() => {});
      return response;
    };
  }

  const OriginalXhr = window.XMLHttpRequest;
  if (typeof OriginalXhr === "function") {
    const originalOpen = OriginalXhr.prototype.open;
    const originalSend = OriginalXhr.prototype.send;

    OriginalXhr.prototype.open = function patchedOpen(method, url, ...rest) {
      this.__simcoAnalyzerCaptureUrl = url;
      return originalOpen.call(this, method, url, ...rest);
    };

    OriginalXhr.prototype.send = function patchedSend(...args) {
      this.addEventListener("load", () => parseAndCapture(this.__simcoAnalyzerCaptureUrl, this.responseText || ""));
      return originalSend.apply(this, args);
    };
  }

  function waitForCapturedJson(matchUrl, requestId) {
    const targetKey = captureKeyForUrl(matchUrl);
    const matches = (key) => key === targetKey || key.startsWith(targetKey);
    const cached = [...capturedJson.values()].find((row) => matches(row.url));
    if (cached && Date.now() - cached.capturedAt < 60 * 1000) {
      postCaptureResponse(requestId, {
        ok: true,
        data: cached.data,
        capturedAt: cached.capturedAt,
        capturedUrl: cached.url,
      });
      return;
    }

    const timeout = window.setTimeout(() => {
      const index = pendingCaptureRequests.findIndex((pending) => pending.requestId === requestId);
      if (index >= 0) pendingCaptureRequests.splice(index, 1);
      postCaptureResponse(requestId, {
        ok: false,
        error: "The official SimCompanies page did not call that API while loading.",
      });
    }, 30000);

    pendingCaptureRequests.push({
      requestId,
      matches,
      timeout,
    });
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    if (!data || data.source !== requestSource) return;

    if (data.type === "getCapturedJson") {
      waitForCapturedJson(data.url, data.requestId);
      return;
    }

    if (data.type !== "getCachedBuildings") return;

    const hasFreshCache = Array.isArray(cachedBuildings) && Date.now() - cachedAt < 5 * 60 * 1000;
    window.postMessage(
      {
        source: responseSource,
        type: "buildingsResponse",
        requestId: data.requestId,
        ok: hasFreshCache,
        buildings: hasFreshCache ? cachedBuildings : [],
        error: hasFreshCache ? "" : "Building status has not loaded yet. Open or refresh the SimCompanies page, then sync again.",
      },
      window.location.origin,
    );
  });
})();
